package mypackage;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List; 

/*
CREATE TABLE `documents`.`note` ( 
	`id` INT(40) NOT NULL AUTO_INCREMENT , 
	`description` TEXT NOT NULL , 
PRIMARY KEY (`id`)) ENGINE = InnoDB;
	
INSERT INTO `note` (`id`, `description`) VALUES 
(NULL, 'Gosho should take the Physics Exam!'), 
(NULL, 'Pena should take the Music Exam!')
;
*/

public class NoteDao {
	
	protected static Connection initMariaDbConn() 
        throws SQLException, ClassNotFoundException {
	
		// JspServletFirst\WebContent\WEB-INF\lib\mariadb-java-client-2.3.0.jar
		String driver = "org.mariadb.jdbc.Driver";
	    String url = "jdbc:mariadb://localhost:3306/";
        String db = "documents"; 
        String uname = "root"; 
        String upass = ""; 
  
        Class.forName(driver); 
        Connection con = DriverManager.getConnection(url + db, uname, upass); 
        return con; 
	}
	
	protected static Connection initMySqlDbConn() 
	        throws SQLException, ClassNotFoundException {
		
		    // JspServletFirst\WebContent\WEB-INF\lib\mysql-connector-java-8.0.11.jar
	        String driver = "com.mysql.jdbc.Driver"; 
	        String url = "jdbc:mysql://localhost:3306/"; 
	        String db = "documents"; 
	        String uname = "root"; 
	        String upass = ""; 
	  
	        Class.forName(driver); 
	        Connection con = DriverManager.getConnection(url + db, uname, upass); 
	        return con; 
	}
	
	public static List<Note> getAllNotes() {
		
		List<Note> notes = new ArrayList<Note>();
		
		try {			
			// Connection conn = initMariaDbConn(); // works!
			Connection conn = initMySqlDbConn(); // works !
			Statement stmt = conn.createStatement();  
			ResultSet rs = stmt.executeQuery("SELECT * FROM note");  
			
			while(rs.next()) {  
				
				Long id = Long.valueOf(rs.getInt("id"));
				String description = rs.getString("description");
				
				Note nt = new Note();
				nt.setId(id);
				nt.setDescription(description);
				notes.add(nt);
				
			}
			conn.close();  
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return notes;
	}

}
